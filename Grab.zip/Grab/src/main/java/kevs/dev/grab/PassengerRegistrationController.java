package kevs.dev.grab;
import database.Account;
import database.Customer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import kevs.dev.grab.Component;

import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class PassengerRegistrationController {


    private final Component component = new Component();
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private TextField email;
    @FXML
    private TextField fullName;
    @FXML
    private TextField phoneNumber;
    @FXML
    private TextField address;

    private Customer customer = new Customer();
    private Account account = new Account();

    @FXML
    private void registered(MouseEvent event) throws Exception {
        account.addAccount(String.valueOf(account.countRowData()+1), username.getText(), password.getText(), "passenger", email.getText());
        customer.addCustomer(String.valueOf(account.countRowData()+1), String.valueOf(customer.countRowData()+1), fullName.getText(), email.getText(), phoneNumber.getText(), address.getText());
        component.Switch("login", "Login", event);
    }

    @FXML
    private void backed(MouseEvent event) throws Exception {
        component.Switch("login", "Login", event);
    }


}
