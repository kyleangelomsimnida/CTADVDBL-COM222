package kevs.dev.grab;
import database.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ResourceBundle;
public class FeedbackCustomerController implements Initializable {
    private final Component component = new Component();
    @FXML
    private TextField name;
    @FXML
    private TextField travel_id;
    @FXML
    private ComboBox<String> roles;
    @FXML
    private TextArea complaint;
    @FXML
    private RadioButton firstStar, secondStar, thirdStar, fourthStar, fifthStar;

    CustomerReport customerReport = new CustomerReport();
    Driver driver = new Driver();
    Trip trip = new Trip();
    Customer customer = new Customer();
    Vehicle vehicle = new Vehicle();

    @FXML
    private void successFeedback(MouseEvent event) throws Exception {
        int driver_id = driver.getId("driver_name", name.getText());
        System.out.println(driver_id);
        int trip_id = trip.getId("reference_numberID", travel_id.getText());
        System.out.println(trip_id);
        if(trip_id != 0 && driver_id != 0) {
            customerReport.addCustomerReport(Integer.toString(customerReport.countRowData()+1), Integer.toString(driver_id), Integer.toString(customer.getId("acc_id", Account.acc_id)), Integer.toString(vehicle.getId("driver_id", String.valueOf(driver_id))), java.sql.Date.valueOf(LocalDate.now()), java.sql.Time.valueOf(LocalTime.now()), complaint.getText(), roles.getValue(), travel_id.getText());
            component.Switch("clientSide", "Grab", event);
        }


    }
    @FXML
        private void back(MouseEvent event) throws Exception {

        component.Switch("clientSide", "Grab", event);
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String[] types = {"Booking issue", "Driver Behavior", "Accident", "Vehicle issue", "Overcharging", "Booking availability issue", "App issue", "Other"};
        roles.getItems().addAll(types);
        roles.getSelectionModel().selectFirst();

        ToggleGroup toggleGroup = new ToggleGroup();
        firstStar.setToggleGroup(toggleGroup);
        secondStar.setToggleGroup(toggleGroup);
        thirdStar.setToggleGroup(toggleGroup);
        fourthStar.setToggleGroup(toggleGroup);
        fifthStar.setToggleGroup(toggleGroup);

        // listen to changes in selected toggle
        toggleGroup.selectedToggleProperty().addListener((observable, oldVal, newVal) -> {
            System.out.println(newVal + " was selected");
        });
    }


}
