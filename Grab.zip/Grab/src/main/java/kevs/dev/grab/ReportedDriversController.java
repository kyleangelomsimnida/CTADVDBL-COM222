package kevs.dev.grab;
import database.Account;
import database.CustomerReport;
import database.Driver;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ReportedDriversController implements Initializable {
    private final Component component = new Component();

    @FXML
    private TableView<DriverObject> table;

    @FXML
    private TableColumn<DriverObject, String> columnDriverID;

    @FXML
    private TableColumn<DriverObject, String> columnName;

    @FXML
    private TableColumn<DriverObject, String> columnPhoneNumber;

    @FXML
    private TableColumn<DriverObject, String> columnEmail;

    private ObservableList<DriverObject> rows = FXCollections.observableArrayList();
    CustomerReport customerReport = new CustomerReport();
    Driver driver = new Driver();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        columnDriverID.setCellValueFactory(new PropertyValueFactory<>("columnDriverID"));
        columnName.setCellValueFactory(new PropertyValueFactory<>("columnName"));
        columnPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("columnPhoneNumber"));
        columnEmail.setCellValueFactory(new PropertyValueFactory<>("columnEmail"));
        String count = "0";

        for(int i = 1; i < 10; i++) {
            try {
                count = String.valueOf(customerReport.countDriverReports(i));
                if (Integer.valueOf(count) >= 5) {
                    ResultSet resultSet = driver.getDriver(String.valueOf(i));
                    if (resultSet.next()) {
                        rows.add(new DriverObject(resultSet.getString("driver_id"), resultSet.getString("driver_name"), resultSet.getString("driver_phone_num"), count));
                    }

                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }



        table.setItems(rows);
    }
}
