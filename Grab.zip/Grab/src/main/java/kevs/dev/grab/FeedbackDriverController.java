package kevs.dev.grab;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;
public class FeedbackDriverController implements Initializable {
    private final Component component = new Component();
    @FXML
    private TextField name;
    @FXML
    private TextField travel_id;
    @FXML
    private ComboBox<String> roles;
    @FXML
    private TextArea complaint;
    @FXML
    private RadioButton firstStar, secondStar, thirdStar, fourthStar, fifthStar;
    @FXML
    private void successFeedback(MouseEvent event) throws Exception {
        component.Switch("DriverSide", "Grab", event);
    }
    @FXML
    private void back(MouseEvent event) throws Exception {
        component.Switch("DriverSide", "Grab", event);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String[] types = {"Booking issue", "Driver Behavior", "Accident", "Vehicle issue", "Overcharging", "Booking availability issue", "App issue", "Other"};
        roles.getItems().addAll(types);
        roles.getSelectionModel().selectFirst();

        ToggleGroup toggleGroup = new ToggleGroup();
        firstStar.setToggleGroup(toggleGroup);
        secondStar.setToggleGroup(toggleGroup);
        thirdStar.setToggleGroup(toggleGroup);
        fourthStar.setToggleGroup(toggleGroup);
        fifthStar.setToggleGroup(toggleGroup);

        // listen to changes in selected toggle
        toggleGroup.selectedToggleProperty().addListener((observable, oldVal, newVal) -> {
            System.out.println(newVal + " was selected");
        });
    }
}
