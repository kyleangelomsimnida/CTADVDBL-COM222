package kevs.dev.grab;
import database.Driver;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ClientController implements Initializable {
    @FXML
    private TableView<DriverObject> table;

    @FXML
    private TableColumn<DriverObject, String> columnDriverID;

    @FXML
    private TableColumn<DriverObject, String> columnName;

    @FXML
    private TableColumn<DriverObject, String> columnPhoneNumber;

    @FXML
    private TableColumn<DriverObject, String> columnEmail;

    private ObservableList<DriverObject> rows = FXCollections.observableArrayList();
    Driver driver = new Driver();
    private final Component component = new Component();
    @FXML
    private void sendFeedback (MouseEvent event) throws Exception {
        component.Switch("feedbackFormCustomer", "Feedback", event);
    }
    @FXML
    private void viewFeedbackHistory(MouseEvent event) throws Exception {
        component.Switch("previousFeedback", "Feedback Log", event);
    }
    @FXML
    private void logout(MouseEvent event) throws Exception {
        component.Switch("login", "Login", event);
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        columnDriverID.setCellValueFactory(new PropertyValueFactory<>("columnDriverID"));
        columnName.setCellValueFactory(new PropertyValueFactory<>("columnName"));
        columnPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("columnPhoneNumber"));
        columnEmail.setCellValueFactory(new PropertyValueFactory<>("columnEmail"));


        try {
            ResultSet resultSet = driver.getResultSet();
            while(resultSet.next()) {
                rows.add(new DriverObject(resultSet.getString("driver_id"), resultSet.getString("driver_name"), resultSet.getString("driver_phone_num"), resultSet.getString("driver_email")));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        table.setItems(rows);
    }
}
