package kevs.dev.grab;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import java.io.IOException;

public class MainController {
    @FXML
    private BorderPane mainPane; // main.fxml's BorderPane

    // Handle navigation from sidebar
    @FXML
    private void navigate(MouseEvent event) {
        Node source = (Node) event.getSource();
        String id = source.getId();

        switch (id) {
            case "dashboardBtn":
                loadPane("dashboard.fxml");
                break;
            case "manageDriversBtn":
                // Load the manage drivers pane
                loadPane("manage_drivers.fxml");
                break;
            case "manageCustomerBtn":
                // Load the manage customers pane
                loadPane("manage_customers.fxml");
                break;
            case "customerFeedbackBtn":
                // Load the customer feedback pane
                loadPane("customer_feedback.fxml");
                break;
            default:
                showError("Unknown navigation item: " + id);
        }
    }

    // Load the selected FXML into the center of the BorderPane
    private void loadPane(String fxmlFileName) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFileName));
            Pane pane = loader.load();
            mainPane.setCenter(pane);
        } catch (IOException e) {
            showError("Failed to load: " + fxmlFileName);
            e.printStackTrace();
        }
    }

    // Show error messages
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}