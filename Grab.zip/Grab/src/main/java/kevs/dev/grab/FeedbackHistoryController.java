package kevs.dev.grab;

import database.Account;
import database.Customer;
import database.CustomerReport;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class FeedbackHistoryController implements Initializable {

    @FXML
    private TableView<DriverObject> table;

    @FXML
    private TableColumn<DriverObject, String> columnDriverID;

    @FXML
    private TableColumn<DriverObject, String> columnName;

    @FXML
    private TableColumn<DriverObject, String> columnPhoneNumber;

    @FXML
    private TableColumn<DriverObject, String> columnEmail;

    private ObservableList<DriverObject> rows = FXCollections.observableArrayList();
    private final Component component = new Component();
    private CustomerReport customerReport = new CustomerReport();
    private Customer customer = new Customer();
    @FXML
    private void homePage(MouseEvent event) throws Exception {
        component.Switch("clientSide", "Grab", event);
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        columnDriverID.setCellValueFactory(new PropertyValueFactory<>("columnDriverID"));
        columnName.setCellValueFactory(new PropertyValueFactory<>("columnName"));
        columnPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("columnPhoneNumber"));
        columnEmail.setCellValueFactory(new PropertyValueFactory<>("columnEmail"));

        try {
            String customer_id = String.valueOf(customer.getId("acc_id", Account.acc_id));

            ResultSet resultSet = customerReport.getUserPreviousHistory("cust_rep_customer", customer_id);
            while(resultSet.next()) {
                rows.add(new DriverObject(resultSet.getString("cust_rep_driver"), resultSet.getString("trip_ref_num"), resultSet.getString("reportType"), resultSet.getString("date")));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }



        table.setItems(rows);
    }
}
