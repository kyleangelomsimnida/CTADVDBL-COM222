package kevs.dev.grab;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.File;
public class Component {

    private static final File logoFile = new File("src/main/resources/assets/truck.png");
    private static final Image logoImage = new Image(logoFile.toURI().toString());

    public void WindowInfo(Stage stage, String windowTitle) {
        stage.setResizable(false);
        stage.getIcons().add(logoImage);
        stage.setTitle(windowTitle);
    }
    public void Switch(String fxml, String windowTitle, MouseEvent event) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml.concat(".fxml")));
        Parent root = loader.load();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        WindowInfo(stage, windowTitle);
        stage.setScene(scene);
        Stage currentStage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        currentStage.close();
        stage.show();
    }
}
