package kevs.dev.grab;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

public class StartController {
    private final Component component = new Component();
    @FXML
    private void createAccount(MouseEvent event) throws Exception {
        component.Switch("passengerRegistration", "Creating Account (Passenger)", event);
    }
    @FXML
    private void loginAccount(MouseEvent event) throws Exception {
        component.Switch("login", "Login", event);
    }
}
