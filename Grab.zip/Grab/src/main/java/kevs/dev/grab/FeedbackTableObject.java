package kevs.dev.grab;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class FeedbackTableObject {
    private final StringProperty columnDriverID;
    private final StringProperty columnName;
    private final StringProperty columnPhoneNumber;
    private final StringProperty columnEmail;

    public FeedbackTableObject(String columnDriverID, String columnName, String columnPhoneNumber, String columnEmail) {
        this.columnDriverID = new SimpleStringProperty(columnDriverID);
        this.columnName = new SimpleStringProperty(columnName);
        this.columnPhoneNumber = new SimpleStringProperty(columnPhoneNumber);
        this.columnEmail = new SimpleStringProperty(columnEmail);
    }

    public String getColumnDriverID() {
        return columnDriverID.get();
    }

    public void setColumnDriverID(String columnDriverID) {
        this.columnDriverID.set(columnDriverID);
    }

    public StringProperty columnDriverIDProperty() {
        return columnDriverID;
    }

    public String getColumnName() {
        return columnName.get();
    }

    public void setColumnName(String columnName) {
        this.columnName.set(columnName);
    }

    public StringProperty columnNameProperty() {
        return columnName;
    }

    public String getColumnPhoneNumber() {
        return columnPhoneNumber.get();
    }

    public void setColumnPhoneNumber(String columnPhoneNumber) {
        this.columnPhoneNumber.set(columnPhoneNumber);
    }

    public StringProperty columnPhoneNumberProperty() {
        return columnPhoneNumber;
    }

    public String getColumnEmail() {
        return columnEmail.get();
    }

    public void setColumnEmail(String columnEmail) {
        this.columnEmail.set(columnEmail);
    }

    public StringProperty columnEmailProperty() {
        return columnEmail;
    }
}

