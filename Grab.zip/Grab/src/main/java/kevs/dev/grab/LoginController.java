package kevs.dev.grab;
import database.Account;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private ComboBox<String> roles;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    private final Component component = new Component();
    private Account account = new Account();

    public LoginController() throws SQLException {
    }


    @FXML
    private void createAccount(MouseEvent event) throws Exception {
        component.Switch("passengerRegistration", "Creating Account (Passenger)", event);
    }
    @FXML
    private void verifyUser(MouseEvent event) throws Exception {
        String role = roles.getValue();

        if(account.isContains("acc_username", username.getText(), "acc_pass", password.getText(), "acc_role", role.toLowerCase()) && role.equals("Administrator")) {
            account.updateCurrentUser(username.getText());
            component.Switch("main", "Grab (Administrator)", event);
        }else if(account.isContains("acc_username", username.getText(), "acc_pass", password.getText(), "acc_role", role.toLowerCase()) && role.equals("Passenger")){
            account.updateCurrentUser(username.getText());
            component.Switch("clientSide", "Grab (Passenger)", event);
        }






















































        System.out.println(Account.acc_id);
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String[] types = {"Passenger", "Administrator"};
        roles.getItems().addAll(types);
        roles.getSelectionModel().selectFirst();
    }
}
