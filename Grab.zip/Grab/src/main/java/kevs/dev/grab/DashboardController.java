package kevs.dev.grab;
import database.Customer;
import database.CustomerReport;
import database.Driver;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {
    private final Component component = new Component();

    @FXML
    private Label passengers;
    @FXML
    private Label drivers;
    @FXML
    private Label feedbacks;

    Customer customer = new Customer();
    Driver driver = new Driver();
    CustomerReport customerReport = new CustomerReport();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            passengers.setText(String.valueOf(customer.countRowData()));
            drivers.setText(String.valueOf(driver.countRowData()));
            feedbacks.setText(String.valueOf(customerReport.countRowData()));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
