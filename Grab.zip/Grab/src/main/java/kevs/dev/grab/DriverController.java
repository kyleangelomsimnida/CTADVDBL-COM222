package kevs.dev.grab;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class DriverController implements Initializable {
    private final Component component = new Component();

    @FXML
    private void sendFeedback (MouseEvent event) throws Exception {
        component.Switch("feedbackFormDriver", "Feedback", event);
    }
    @FXML
    private void viewFeedbackHistory(MouseEvent event) throws Exception {
        component.Switch("previousFeedback", "Feedback Log", event);
    }
    @FXML
    private void logout(MouseEvent event) throws Exception {
        component.Switch("login", "Login", event);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
