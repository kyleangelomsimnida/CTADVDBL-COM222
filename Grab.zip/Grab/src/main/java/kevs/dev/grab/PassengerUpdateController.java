package kevs.dev.grab;

import javafx.fxml.FXML;

public class PassengerUpdateController {
    private final Component component = new Component();

    @FXML
    public void registered() {

    }
}
