package kevs.dev.grab;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class RoleController implements Initializable {
    @FXML
    private ComboBox<String> roles;
    private final Component component = new Component();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String types = "Passenger";
        roles.getItems().addAll(types);
    }
    @FXML
    private void navigate(MouseEvent event) throws Exception {
        String chosenRole = roles.getValue();

        if(chosenRole.equals("Passenger")) {
            System.out.println("Passenger");
            component.Switch("passengerRegistration", "Creating Account (Passenger)", event);
        }
        if(chosenRole.equals("Driver")) {
            System.out.println("Driver");
            component.Switch("driverRegistration", "Creating Account (Driver)", event);

        }

    }
}
