module kevs.dev.grab {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens kevs.dev.grab to javafx.fxml;
    exports kevs.dev.grab;
}