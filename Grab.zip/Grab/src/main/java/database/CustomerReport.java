package database;

import java.sql.*;

public class CustomerReport {
    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "customer_report";

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public CustomerReport() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

            // Extract data from result set

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addCustomerReport(String customer_reportid, String cust_rep_driver, String cust_rep_customer, String cust_rep_vehicle, Date date, Time time, String description, String reportType, String trip_ref_num) throws SQLException {
        String sql = "insert into customer_report (customer_reportid, cust_rep_driver, cust_rep_customer, cust_rep_vehicle, date, time, decsription, reportType, trip_ref_num) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, customer_reportid);
        preparedStatement.setString(2, cust_rep_driver);
        preparedStatement.setString(3, cust_rep_customer);
        preparedStatement.setString(4, cust_rep_vehicle);
        preparedStatement.setDate(5, date);
        preparedStatement.setTime(6, time);
        preparedStatement.setString(7, description);
        preparedStatement.setString(8, reportType);
        preparedStatement.setString(9, trip_ref_num);

        preparedStatement.executeUpdate();
    }

    public int countRowData() throws SQLException {
        String sql = "select count(*) from customer_report";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int rowCount = resultSet.getInt(1);
            return rowCount;
        }
        return 0;


    }

    public int countDriverReports(int index) throws SQLException {
        String sql = "select count(*) from customer_report where cust_rep_driver = '" + index + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int rowCount = resultSet.getInt(1);
            return rowCount;
        }
        return 0;

    }
    public ResultSet getUserPreviousHistory(String columnName, String dataValue) throws SQLException {
        String sql = "select cust_rep_driver, trip_ref_num, reportType, date from customer_report where " + columnName + " = '" + dataValue + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        return preparedStatement.executeQuery();


    }
}
