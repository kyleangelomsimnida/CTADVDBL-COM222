package database;

import java.sql.*;

public class Trip {
    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "trip";

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Trip() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

            // Extract data from result set

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addTrip(String reference_numberID, String ref_num_driver, String ref_num_customer, String ref_num_vehicle, String trip_start, String trip_end, String origin, String destination, String distance, String trip_transport_mode, String trip_cost) throws SQLException {
        String sql = "insert into trip (reference_numberID, ref_num_driver, ref_num_customer, ref_num_vehicle, trip_start, trip_end, origin, destination, distance, trip_transport_mode, trip_cost) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, Integer.parseInt(reference_numberID));
        preparedStatement.setInt(2, Integer.parseInt(ref_num_driver));
        preparedStatement.setInt(3, Integer.parseInt(ref_num_customer));
        preparedStatement.setInt(4, Integer.parseInt(ref_num_vehicle));
        preparedStatement.setString(5, trip_start);
        preparedStatement.setString(6, trip_end);
        preparedStatement.setString(7, origin);
        preparedStatement.setString(8, destination);
        preparedStatement.setString(9, distance);
        preparedStatement.setString(10, trip_transport_mode);
        preparedStatement.setString(11, trip_cost);

        preparedStatement.executeUpdate();
    }

    public int countRowData() throws SQLException {
        String sql = "select count(*) from customer";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int rowCount = resultSet.getInt(1);
            return rowCount;
        }
        return 0;


    }

    public int getId(String columnName, String dataValue) throws SQLException {
        String sql = "select ref_num_driver from trip where " + columnName + " = '" + dataValue + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();
        if(resultSet.next()) {
            return resultSet.getInt("ref_num_driver");
        }
        else return 0;

    }


    public static void main(String[] args) throws SQLException {
        Trip trip = new Trip();

        trip.addTrip("1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1");
    }
}
