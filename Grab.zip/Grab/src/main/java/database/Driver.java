package database;

import java.sql.*;

public class Driver {
    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "driver";

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Driver() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

            // Extract data from result set

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addDriver(String driver_id, String driver_name, String driver_lice_num, String driver_address, String driver_email, String driver_phone_num, String driver_birth_date, String driver_lice_exdate) throws SQLException {
        String sql = "insert into driver (driver_id, driver_name, driver_lice_num, driver_address, driver_email, driver_phone_num, driver_birth_date, driver_lice_exdate) values (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, driver_id);
        preparedStatement.setString(2, driver_name);
        preparedStatement.setString(3, driver_lice_num);
        preparedStatement.setString(4, driver_address);
        preparedStatement.setString(5, driver_email);
        preparedStatement.setString(6, driver_phone_num);
        preparedStatement.setString(7, driver_birth_date);
        preparedStatement.setString(8, driver_lice_exdate);

        preparedStatement.executeUpdate();
    }


    public int getId(String columnName, String dataValue) throws SQLException {
        String sql = "select driver_id from driver where " + columnName + " = '" + dataValue + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();
        if(resultSet.next()) {
            return resultSet.getInt("driver_id");
        }
        else return 0;

    }

    public ResultSet getResultSet() throws SQLException {
        String sql = "select driver_id, driver_name, driver_phone_num, driver_email from driver";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        return preparedStatement.executeQuery();
    }

    public int countRowData() throws SQLException {
        String sql = "select count(*) from driver";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int rowCount = resultSet.getInt(1);
            return rowCount;
        }
        return 0;


    }

    public ResultSet getDriver(String dataValue) throws SQLException {
        String sql = "select * from driver where driver_id = '" + dataValue + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        return preparedStatement.executeQuery();
    }
}
