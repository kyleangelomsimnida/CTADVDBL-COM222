package database;

import java.sql.*;

public class Vehicle {
    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "trip";

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Vehicle() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

            // Extract data from result set

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public int getId(String columnName, String dataValue) throws SQLException {
        String sql = "select vehicle_id from vehicle where " + columnName + " = '" + dataValue + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();
        if(resultSet.next()) {
            return resultSet.getInt("vehicle_id");
        }
        else return 0;

    }
    public void addVehicle(String vehicle_id, String driver_id, String lice_plate, String model, String year, String color, String vin) throws SQLException {
        String sql = "insert into vehicle ( vehicle_id, driver_id, lice_plate, model, year, color, vin) values (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, vehicle_id);
        preparedStatement.setString(2, driver_id);
        preparedStatement.setString(3, lice_plate);
        preparedStatement.setString(4, model);
        preparedStatement.setString(5, year);
        preparedStatement.setString(6, color);
        preparedStatement.setString(7, vin);

        preparedStatement.executeUpdate();
    }

    public static void main(String[] args) throws SQLException {
        Vehicle vehicle = new Vehicle();
        vehicle.addVehicle("1", "1", "1","1","1","1","1");
    }
}
