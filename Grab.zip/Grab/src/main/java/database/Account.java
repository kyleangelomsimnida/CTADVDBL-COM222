package database;
import java.sql.*;

public class Account {
    // JDBC URL, username, and password of MySQL server
    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "account";
    public static String acc_id;

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Account() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addAccount(String acc_id, String acc_username, String acc_pass, String acc_role, String acc_email) throws SQLException {
        String sql = "insert into account (acc_id, acc_username, acc_pass, acc_role, acc_email) values (?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, acc_id);
        preparedStatement.setString(2, acc_username);
        preparedStatement.setString(3, acc_pass);
        preparedStatement.setString(4, acc_role);
        preparedStatement.setString(5, acc_email);

        preparedStatement.executeUpdate();

    }

    public boolean isContains(String columnName, String dataValue) throws SQLException {
        resultSet = statement.executeQuery("SELECT "+ columnName + " from " + tableName +" where "+ columnName + " = '" + dataValue + "'");
        // Retrieve by column name
        // Display values
        return resultSet.next();
    }

    public boolean isContains(String columnName1, String dataValue1, String columnName2, String dataValue2) throws SQLException {
        resultSet = statement.executeQuery("SELECT "+ columnName1 +", " + columnName2 + " from " + tableName +" where "+ columnName1 + " = '" + dataValue1 + "' and " + columnName2 + " = '" + dataValue2);
        // Retrieve by column name
        // Display values
        return resultSet.next();
    }

    public boolean isContains(String columnName1, String dataValue1, String columnName2, String dataValue2, String columnName3, String dataValue3) throws SQLException {
        resultSet = statement.executeQuery("SELECT "+ columnName1 +", " + columnName2 + " from " + tableName +" where "+ columnName1 + " = '" + dataValue1 + "' and " + columnName2 + " = '" + dataValue2 + "' and " + columnName3 + " = '" + dataValue3 + "'");
        // Retrieve by column name
        // Display values
        return resultSet.next();
    }

    public void updateCurrentUser(String username) throws SQLException {
        String sql = "select acc_id from account where acc_username = '" +username + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();

        if(resultSet.next()) {
            acc_id = resultSet.getString("acc_id");
        }
    }

    public int countRowData() throws SQLException {
        String sql = "select count(*) from account";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int rowCount = resultSet.getInt(1);
            return rowCount;
        }
        return 0;


    }

    public static void main(String[] args) throws SQLException {

    }
}