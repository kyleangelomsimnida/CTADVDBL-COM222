package database;

import java.sql.*;

public class Notification {
    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "notification";

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Notification() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

            // Extract data from result set

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addNotification(String notif_id, String notif_cust_id, String notif_driver_id, Date date_sent, Time time_sent, String email_sub, String email_body, String email_sender, String email_receiver) throws SQLException {
        String sql = "insert into notification (notif_id, notif_cust_id, notif_driver_id, date_sent, time_sent, email_sub, email_body, email_sender, email_receiver) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, notif_id);
        preparedStatement.setString(2, notif_cust_id);
        preparedStatement.setString(3, notif_driver_id);
        preparedStatement.setDate(4, date_sent);
        preparedStatement.setTime(5, time_sent);
        preparedStatement.setString(6, email_sub);
        preparedStatement.setString(7, email_body);
        preparedStatement.setString(8, email_sender);
        preparedStatement.setString(9, email_receiver);

        preparedStatement.executeUpdate();

    }
}
