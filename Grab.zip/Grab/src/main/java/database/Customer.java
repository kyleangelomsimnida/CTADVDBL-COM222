package database;

import java.sql.*;

public class Customer {

    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "customer";

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Customer() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

            // Extract data from result set

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addCustomer(String acc_id, String cus_id, String cus_name, String cus_email, String cus_phonenum, String cus_address) throws SQLException {
        String sql = "insert into customer (acc_id, cus_id, cus_name, cus_email, cus_phonenum, cus_address) values (?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, acc_id);
        preparedStatement.setString(2, cus_id);
        preparedStatement.setString(3, cus_name);
        preparedStatement.setString(4, cus_email);
        preparedStatement.setString(5, cus_phonenum);
        preparedStatement.setString(6, cus_address);

        preparedStatement.executeUpdate();
    }

    public int getId(String columnName, String dataValue) throws SQLException {
        String sql = "select cus_id from customer where " + columnName + " = '" + dataValue + "'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();
        if(resultSet.next()) {
            return resultSet.getInt("cus_id");
        }
        else return 0;

    }
    public int countRowData() throws SQLException {
        String sql = "select count(*) from customer";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int rowCount = resultSet.getInt(1);
            return rowCount;
        }
        return 0;


    }
}
