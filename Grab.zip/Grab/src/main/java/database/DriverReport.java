package database;

import java.sql.*;

public class DriverReport {
    private String URL = "jdbc:mysql://127.0.0.1:3306/my_database";
    private String USER = "root";
    private String PASSWORD = "Jezreal114";
    private String tableName = "driver_report";

    // JDBC variables for opening and managing connection
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public DriverReport() {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Execute a query
            statement = connection.createStatement();

            // Extract data from result set

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addDriverReport(String driver_reportID, String driver_rep_driver, String driver_rep_customer, String driver_rep_vehicle, Date date, Time time, String location, String description, String reportType, String trip_ref_num) throws SQLException {
        String sql = "insert into driver_report (driver_reportID, driver_rep_driver, driver_rep_customer, driver_rep_vehicle, date, time, location, decsription, reportType, trip_ref_num) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, driver_reportID);
        preparedStatement.setString(2, driver_rep_driver);
        preparedStatement.setString(3, driver_rep_customer);
        preparedStatement.setString(4, driver_rep_vehicle);
        preparedStatement.setDate(5, date);
        preparedStatement.setTime(6, time);
        preparedStatement.setString(7, location);
        preparedStatement.setString(8, description);
        preparedStatement.setString(9, reportType);
        preparedStatement.setString(10, trip_ref_num);

        preparedStatement.executeUpdate();
    }
}
